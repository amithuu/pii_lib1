# steps to build
   * python setup.py sdist
   * copy and paste the tar.gz. 

# steps: to install
   * after Copying the pii_library.0.1.0.tar.gz
   * install using pip install pii_library.0.1.0.tar.gz

# from pii_library.mask import mask_data
# from pii_library.encryption import encrypt_data, decrypt_data


