from django.apps import AppConfig # type:ignore


class RhythmPIIConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pii_library'
